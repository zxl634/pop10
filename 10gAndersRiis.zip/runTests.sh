fsharpc --nologo cards.fs simpleJack.fs test.fsx && mono test.exe
