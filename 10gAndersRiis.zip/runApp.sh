fsharpc --nologo cards.fs simpleJack.fs simpleJackApp.fsx && mono simpleJackApp.exe
